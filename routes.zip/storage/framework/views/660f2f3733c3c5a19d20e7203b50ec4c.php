<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
© <?php echo e(date('Y')); ?> Takoyaki Babon. All rights reserved.
</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH C:\Users\fajri\Documents\projek takoyaki\backend\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>