<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\fajri\Documents\projek takoyaki\backend\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>