<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Konfirmasi Email')]); ?>
    <div class="mb-6 text-sm text-gray-700 bg-[#FFFBEA] p-4 rounded-lg border border-[#EBF400]">
        Terima kasih telah mendaftar! Sebelum memulai, silakan verifikasi alamat email Anda dengan mengeklik tautan yang
        telah kami kirimkan ke email Anda. Jika Anda tidak menerima email, kami dengan senang hati akan mengirimkannya
        kembali.
    </div>

    <?php if(session('status') == 'verification-link-sent'): ?>
        <div class="p-4 mb-6 text-sm font-medium text-green-700 bg-green-100 border border-green-300 rounded-lg">
            Tautan verifikasi baru telah dikirim ke alamat email yang Anda gunakan saat pendaftaran.
        </div>
    <?php endif; ?>

    <div class="flex flex-col items-center justify-between gap-4 mt-6 sm:flex-row">
        <!-- Tombol Kirim Ulang -->
        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
            <?php echo csrf_field(); ?>
            <button
                class="w-full sm:w-auto px-6 py-2 bg-[#EBF400] text-black font-semibold rounded-lg shadow-md hover:bg-[#D6D200] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#EBF400]">
                Kirim Ulang Email Verifikasi
            </button>
        </form>

        <!-- Tombol Logout -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                class="w-full sm:w-auto px-6 py-2 bg-white text-[#EBF400] font-semibold rounded-lg shadow-md border border-[#EBF400] hover:bg-[#FFFBEA] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#EBF400]">
                Keluar
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\fajri\Documents\projek takoyaki\backend\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>