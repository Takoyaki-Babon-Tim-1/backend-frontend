<?php $__env->startSection('content'); ?>
    <div class="container px-5 my-[30px] ">
        <div class="flex items-center justify-between w-full mb-8">
            <a href="/">
                <div
                    class="flex items-center justify-center w-10 h-10 rounded-full bg-[#EBF400] transition-all duration-300">
                    <img src="<?php echo e(asset('assets/images/icons/arrow-left.svg')); ?>" class="object-contain w-5 h-5" alt="icon">
                </div>
            </a>
            <h1 class="text-2xl font-bold ">Pembelianmu</h1>
            <span class="max-w-none"></span>
        </div>
        <div class="mt-3">
            <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-col py-4 border-gray-400 md:flex-row">
                    <div class="flex-shrink-0">
                        <img src="<?php echo e(Storage::url($item->product->thumbnail)); ?>" alt="Product image"
                            class="object-contain w-32 h-32 rounded-xl">
                    </div>
                    <div class="w-full mt-4 md:ml-6">
                        <h2 class="text-lg font-bold"><?php echo e($item->product->name); ?></h2>
                        
                        <div class="flex items-center mt-4">
                            <span class="mr-2 text-gray-600">Kuantitas:</span>
                            <div class="flex items-center">
                                
                                <form
                                    action="<?php echo e($item->quantity > 1 ? route('cart.update', $item->id) : route('cart.remove', $item->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php if($item->quantity > 1): ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="quantity" value="<?php echo e($item->quantity - 1); ?>">
                                        <button class="px-2 py-1 bg-gray-200 rounded-l-lg">-</button>
                                    <?php else: ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="px-2 py-1 bg-gray-200 rounded-l-lg">-</button>
                                    <?php endif; ?>
                                </form>
                                
                                <span class="mx-2 text-gray-600"><?php echo e($item->quantity); ?></span>
                                
                                <form action="<?php echo e(route('cart.update', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="quantity" value="<?php echo e($item->quantity + 1); ?>">
                                    <button class="px-2 py-1 bg-gray-200 rounded-r-lg">+</button>
                                </form>
                            </div>
                            <?php
                                $total_products = $item->product->total * $item->quantity;
                            ?>
                            
                            <span class="ml-2 font-bold">Rp <?php echo e(number_format($total_products, 0, ',', '.')); ?></span>
                            <div class="ml-auto">
                                <form action="<?php echo e(route('cart.remove', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button><img src="/assets/images/icons/hapus.svg" class="w-5 h-5"
                                            alt="icons"></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Tidak ada produk yang ditambahkan</p>
            <?php endif; ?>
        </div>

        <form action="<?php echo e(route('payment.checkout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label for="message" class="block mt-3 mb-2 text-lg font-semibold text-gray-900">
                    Catatan untuk penjual nih 😊
                </label>
                <textarea id="message" name="message" rows="4"
                    class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300"
                    placeholder="Jangan pakai sayuran ya!"></textarea>
            </div>
            <div class="flex flex-col items-end mt-8">
                <div class="flex items-center justify-between w-full">
                    <span class="text-gray-600">Total Harga:</span>
                    <span class="text-xl font-bold">Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></span>
                </div>
                <button type="submit"
                    class="px-4 py-2 mt-4 w-full flex justify-center font-semibold text-black bg-[#EBF400] hover:bg-[#EBF400] rounded-full">
                    <p>Bayar Sekarang</p>
                </button>
            </div>
        </form>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fajri\Documents\projek takoyaki\backend\resources\views/cart/index.blade.php ENDPATH**/ ?>