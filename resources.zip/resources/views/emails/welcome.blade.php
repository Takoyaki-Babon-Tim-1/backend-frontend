<!DOCTYPE html>
<html>

<head>
    <title>{{ $title }}</title>
</head>

<body>
    <p>{{ $body }}</p>
</body>

</html>
